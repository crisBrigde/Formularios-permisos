// Inicializa EmailJS
(function() {
  emailjs.init("1024527370bridge");
})();

document.getElementById("permisoForm").addEventListener("submit", function(event) {
  event.preventDefault();

  const archivoInput = document.querySelector('input[name="archivo"]');
  const archivo = archivoInput.files[0];

  if (!archivo) {
    alert("Por favor, adjunta un archivo PDF.");
    return;
  }

  const form = this;

  // 1. Enviar formulario por correo con EmailJS
  emailjs.sendForm("service_f5oi8fy", "template_rOg100b", form)
    .then(() => {
      alert("¡Permiso enviado exitosamente!");
      form.reset();

      // 2. Enviar mensaje de alerta a WhatsApp de Bienestar
      const nombre = document.getElementById("nombre").value;
      const documento = document.getElementById("documento").value;
      const programa = document.getElementById("programa").value;
      const motivo = document.getElementById("motivo").value;
      const fecha = document.getElementById("fecha").value;

      const mensajeBienestar = `📩 NUEVO PERMISO\n👤 ${nombre}\n🆔 ${documento}\n🛠️ ${programa}\n📝 ${motivo}\n📅 ${fecha}`;
      const bienestarTelefono = "573112054295"; // Tu número de WhatsApp
      const apikey = "4620920"; // Tu API Key de CallMeBot

      fetch(`https://api.callmebot.com/whatsapp.php?phone=${bienestarTelefono}&text=${encodeURIComponent(mensajeBienestar)}&apikey=${apikey}`)
        .then(response => {
          if (response.ok) {
            console.log("Mensaje enviado a Bienestar.");
          } else {
            console.error("No se pudo enviar a Bienestar.");
          }
        });

      // 3. Enviar respuesta automática al WhatsApp del estudiante
      const numeroEstudiante = document.getElementById("telefono").value;
      const mensajeEstudiante = `Hola ${nombre}, tu permiso ha sido otorgado ✅. Gracias por enviarlo correctamente.`;

      fetch(`https://api.callmebot.com/whatsapp.php?phone=${numeroEstudiante}&text=${encodeURIComponent(mensajeEstudiante)}&apikey=${apikey}`)
        .then(response => {
          if (response.ok) {
            console.log("Mensaje enviado al estudiante.");
          } else {
            console.error("No se pudo enviar al estudiante.");
          }
        });

    })
    .catch((error) => {
      alert("Error al enviar el permiso: " + JSON.stringify(error));
    });
});